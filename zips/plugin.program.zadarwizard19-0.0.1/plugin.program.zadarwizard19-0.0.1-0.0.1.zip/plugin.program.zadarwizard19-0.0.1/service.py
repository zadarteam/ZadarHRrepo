# -*- coding: utf-8 -*-

if __name__ == '__main__':
	from resources.lib.modules._service import startup
	s = startup()
	s.run_startup()